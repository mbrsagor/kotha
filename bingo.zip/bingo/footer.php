</div>
<?php bingo_ruby_render_footer(); ?>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>