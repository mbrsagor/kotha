<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** -------------------------------------------------------------------------------------------------------------------------
 * @param string $flickr_id
 * @param int    $num_images
 * @param string $tags
 *
 * @return array|mixed
 * get flickr data
 */
if ( ! function_exists( 'bingo_ruby_plugin_data_flickr' ) ) {
	function bingo_ruby_plugin_data_flickr( $flickr_id, $num_images = 9, $tags = '' ) {
		if ( empty( $flickr_id ) ) {
			return array();
		};

		$bingo_ruby_args = array( 'timeout' => 100 );

		$response = wp_remote_get( 'http://api.flickr.com/services/feeds/photos_public.gne?format=json&id=' . urlencode( $flickr_id ) . '&nojsoncallback=1&tags=' . urlencode( $tags ), $bingo_ruby_args );
		if ( is_wp_error( $response ) || '200' != $response['response']['code'] ) {
			return array();
		}
		$response = wp_remote_retrieve_body( $response );
		$response = str_replace( "\\'", "'", $response );
		$content  = json_decode( $response, true );
		if ( is_array( $content ) ) {
			$content = array_slice( $content['items'], 0, $num_images );
			foreach ( $content as $i => $v ) {
				$content[ $i ]['media'] = preg_replace( '/_m\.(jp?g|png|gif)$/', '_q.\\1', $v['media']['m'] );
			}

			return $content;
		} else {
			return array();
		}

	}
}


/**
 * @param        $instagram_token
 * @param string $cache_name
 * @param int    $num_images
 * @param string $tags
 *
 * @return array|mixed|object|string
 * get instagram data
 */
if ( ! function_exists( 'bingo_ruby_plugin_data_instagram' ) ) {
	function bingo_ruby_plugin_data_instagram( $settings ) {
		$cache_name  = 'bingo_instagram_cache';
		$data_images = array();

		if ( ! empty( $settings['cache_id'] ) ) {
			$cache_id = $settings['cache_id'];
		} else {
			$cache_id = 0;
		}

		$cache_data = get_transient( $cache_name );

		if ( empty($cache_data) || ! is_array( $cache_data ) ) {
			$cache_data = array();
		}

		if ( ! empty( $cache_data[ $cache_id ] ) ) {
			return $cache_data[ $cache_id ];
		} else {

			if ( empty( $settings['instagram_token'] ) ) {
				$data_images['error'] = esc_html__( 'Instagram token not found', 'bingo-core' );

				return $data_images;
			}

			$params = array(
				'sslverify' => false,
				'timeout'   => 100
			);

			$url      = 'https://graph.instagram.com/me/media?fields=id,caption,media_url,permalink&access_token=' . trim( $settings['instagram_token'] );
			$response = wp_remote_get( $url, $params );

			if ( is_wp_error( $response ) || empty( $response['response']['code'] ) || 200 != $response['response']['code'] ) {

				$data_images['error'] = esc_html__( 'Could not connect to Instagram API server, Please recheck the Token or hosting to ensure.', 'bingo-core' );

				$response             = json_decode( wp_remote_retrieve_body( $response ) );
				if ( ! empty( $response->error->message ) ) {
					$data_images['error'] = $response->error->message;
				}

				$cache_data[ $cache_id ] = $data_images;
				set_transient( $cache_name, $cache_data, 12000 );
				return $data_images;
			};

			$response = json_decode( wp_remote_retrieve_body( $response ) );
			if ( ! empty( $response->data ) && is_array( $response->data ) ) {
				foreach ( $response->data as $image ) {

					$caption   = esc_html__( 'instagram image', 'bingo_core' );
					$link      = '#';
					$likes     = '';
					$comments  = '';
					$thumbnail = '#';

					if ( ! empty( $image->permalink ) ) {
						$link = esc_url( $image->permalink );
					}

					if ( ! empty( $image->media_url ) ) {
						$thumbnail = esc_url( $image->media_url );
					}
					if ( ! empty( $image->$caption ) ) {
						$caption = wp_kses_post( $image->$caption );
					}

					$data_images[] = array(
						'thumbnail_src' => $thumbnail,
						'caption'       => wp_kses_post( $caption ),
						'link'          => $link,
						'likes'         => $likes,
						'comments'      => $comments
					);
				}

				$cache_data[ $cache_id ] = $data_images;
				delete_transient( $cache_name );
				set_transient( $cache_name, $cache_data, 12000 );
			} else {
				$data_images['error'] = esc_html__( 'Token did not work or has expired, Try to create a new token.', 'bingo-core' );
			}

			return $data_images;
		}

	}
}
