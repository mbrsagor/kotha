<?php
/** composer fields template */
if ( ! function_exists( 'bingo_composer_templates' ) ) {
	function bingo_composer_templates() {
		$template = array();
		global $pagenow;
		if ( ( 'post.php' == $pagenow || 'post-new.php' == $pagenow ) && get_current_screen()->post_type == 'page' ) {
			if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'elementor' ) {
				return;
			}

			$str = '';
			$str .= '<div class="ruby-block-item">';
			$str .= '<input type="hidden" class="ruby-block-order">';
			$str .= '<input type="hidden" class="ruby-block-name">';
			$str .= '<div class="ruby-block-bar">';
			$str .= '<i class="ruby-block-move">#</i>';
			$str .= '<div class="ruby-block-label"></div>';
			$str .= '<div class="ruby-block-toolbox">';
			$str .= '<a class="ruby-block-open-option" href="#">+</a>';
			$str .= '<a class="ruby-block-delete" href="#">x</a>';
			$str .= '</div>';
			$str .= '</div>';
			$str .= '<div class="ruby-block-options-wrap hidden">';
			$str .= '<div class="ruby-block-description"></div>';
			$str .= '<div class="ruby-filter-link"></div>';
			$str .= '<div class="ruby-block-content"></div>';
			$str .= '</div>';
			$str .= '</div>';
			$template['block'] = $str;

			// block option
			$str = '';
			$str .= '<div class="ruby-block-option">';
			$str .= '<div class="ruby-block-option-label-wrap">';
			$str .= '<label class="ruby-block-option-label"></label>';
			$str .= '<div class="ruby-block-option-description"></div>';
			$str .= '</div>';
			$str .= '<div class="ruby-block-option-inner"></div>';
			$str .= '</div>';
			$template['block_option'] = $str;

            $template['input']['text']           = '<input class="ruby-field ruby-text" type="text">';
            $template['input']['num']            = '<input class="ruby-field ruby-number" type="number" name="quantity" min="0">';
            $template['input']['posts_per_page'] = '<input class="ruby-field ruby-number" type="number" name="quantity" min="1">';
            $template['input']['textarea']       = '<textarea class="ruby-field ruby-textarea" rows="9"></textarea>';
            $template['input']['category']       = bingo_category_dropdown_select();
            $template['input']['categories']     = bingo_categories_dropdown_select();
            $template['input']['post_format']    = bingo_post_format_dropdown_select();
            $template['input']['enable']         = bingo_enable_dropdown_select();
            $template['input']['authors']        = bingo_author_dropdown_select();
            $template['input']['orderby']        = bingo_orderby_dropdown_select();
            $template['input']['viewmore']       = bingo_viewmore_dropdown_select();
            $template['input']['custom_html']    = '<textarea class="ruby-field ruby-raw-html" rows="9"></textarea>';
            $template['input']['summary_type']   = bingo_summary_dropdown_select();
            $template['input']['position']       = bingo_position_dropdown_select();
            $template['input']['wrap_mode']      = bingo_wrapmode_dropdown_select();


            //Fields Title
            $template['title']['title'] = esc_html__('Title', 'bingo-core');
            $template['title']['title_url'] = esc_html__('Title Url', 'bingo-core');
            $template['title']['category_id'] = esc_html__('Category Filter', 'bingo-core');
            $template['title']['category_ids'] = esc_html__('Multiple Categories Filter', 'bingo-core');
            $template['title']['tags'] = esc_html__('Tags slug filter', 'bingo-core');
            $template['title']['post_id'] = esc_html__('Post ID filter', 'bingo-core');
            $template['title']['post_format'] = esc_html__('Post Format Filter', 'bingo-core');
            $template['title']['authors'] = esc_html__('Authors Filter', 'bingo-core');
            $template['title']['posts_per_page'] = esc_html__('Number Of Posts', 'bingo-core');
            $template['title']['slides_per_page'] = esc_html__('Number Of Slider', 'bingo-core');
            $template['title']['offset'] = esc_html__('Post Offset', 'bingo-core');
            $template['title']['orderby'] = esc_html__('Sort Order', 'bingo-core');
            $template['title']['excerpt'] = esc_html__('Post Excerpt', 'bingo-core');
            $template['title']['readmore'] = esc_html__('Read More Button', 'bingo-core');
            $template['title']['big_first'] = esc_html__('1st Classic Layout', 'bingo-core');
            $template['title']['summary_type'] = esc_html__('Classic Summary Type', 'bingo-core');
            $template['title']['position'] = esc_html__('Big Column Position', 'bingo-core');
            $template['title']['excerpt_classic'] = esc_html__('Classic Post Excerpt', 'bingo-core');
            $template['title']['auto_play'] = esc_html__('Auto Play Video', 'bingo-core');

            //block static image
            $template['title']['image_url'] = esc_html__('Image URL', 'bingo-core');
            $template['title']['image_link'] = esc_html__('Image Link', 'bingo-core');
            $template['title']['button_title'] = esc_html__('Button Title', 'bingo-core');

            //block code box
            $template['title']['wrap_mode'] = esc_html__('Block Wrapper Mode', 'bingo-core');
            $template['title']['custom_html'] = esc_html__('Custom HTML', 'bingo-core');
            $template['title']['shortcode'] = esc_html__('ShortCodes', 'bingo-core');

            //block ads
            $template['title']['ad_title'] = esc_html__('Ad title', 'bingo-core');
            $template['title']['ad_url'] = esc_html__('Ad URL', 'bingo-core');
            $template['title']['ad_image'] = esc_html__('Ad Image URL', 'bingo-core');
            $template['title']['ad_script'] = esc_html__('Ad scripts', 'bingo-core');

            //block style
            $template['title']['block_style'] = esc_html__('Blog Style', 'bingo-core');
            $template['desc']['block_style'] = esc_html__('select color style for this block', 'bingo-core');
            $template['input']['block_style'] = bingo_ruby_theme_config::style_dropdown_select();

            //Fields Description
            $template['desc']['title'] = esc_html__('optional - input title for this block', 'bingo-core');
            $template['desc']['title_url'] = esc_html__('optional - input title URL for this block', 'bingo-core');
            $template['desc']['sub_title'] = esc_html__('optional - show sub title of block', 'bingo-core');
            $template['desc']['category_id'] = esc_html__('filter your posts by category ID', 'bingo-core');
            $template['desc']['category_ids'] = esc_html__('filter your posts by category IDs. This option will override on "category filter" option', 'bingo-core');
            $template['desc']['tags'] = esc_html__('filter your posts by tags, Enter here tags separated by commas (example: tag1,tag2,tag3)', 'bingo-core');
            $template['desc']['post_id'] = esc_html__('filter your posts by post ID, Enter here posts ID separated by commas (example: ID1,ID2,ID3)', 'bingo-core');
            $template['desc']['authors'] = esc_html__('filter your pots by authors', 'bingo-core');
            $template['desc']['posts_per_page'] = esc_html__('select numbers of posts you want to show at once', 'bingo-core');
            $template['desc']['slides_per_page'] = esc_html__('select numbers of slides you want to show at once', 'bingo-core');
            $template['desc']['offset'] = esc_html__('select number of posts to displace or pass over. Leave blank or set 0 if you want to show at the beginning', 'bingo-core');
            $template['desc']['orderby'] = esc_html__('select sort order type for this block', 'bingo-core');
            $template['desc']['excerpt'] = esc_html__('select a length for the content excerpt, leave blank or set 0 if you want to disable it', 'bingo-core');
            $template['desc']['excerpt_classic'] = esc_html__('select a length for the content excerpt of classic layout, this option only affect when you enable Use Post Excerpt option, leave blank or set 0 if you want to disable it', 'bingo-core');
            $template['desc']['readmore'] = esc_html__('show or hide "Read More" button of this block', 'bingo-core');
            $template['desc']['big_first'] = esc_html__('show the classic layout at top of post listing', 'bingo-core');
            $template['desc']['summary_type'] = esc_html__('Select summary type for classic layouts of this block', 'bingo-core');
            $template['desc']['position'] = esc_html__('select the position for the big column of this block', 'bingo-core');
            $template['desc']['post_format'] = esc_html__('filter your posts by post format type', 'bingo-core');
            $template['desc']['auto_play'] = esc_html__('Auto the first video of this block when scrolling to it', 'bingo-core');

            //thumbnail position
            $template['title']['thumb_position'] = esc_html__('Thumbnail Position', 'bingo-core');
            $template['desc']['thumb_position'] = esc_html__('select the position for post thumbnails of this block', 'bingo-core');

            //block static image
            $template['desc']['image_url'] = esc_html__('input the image URL', 'bingo-core');
            $template['desc']['image_link'] = esc_html__('input the destination URl, Leave blank you only want to show image', 'bingo-core');
            $template['desc']['button_title'] = esc_html__('input title for the button', 'bingo-core');

            //block code box
            $template['desc']['wrap_mode'] = esc_html__('show block contents in full width or has max width mode', 'bingo-core');
            $template['desc']['custom_html'] = esc_html__('Input your text, HTML codes and video embed codes...', 'bingo-core');
            $template['desc']['shortcode'] = esc_html__('input  your shortcode. It is priority than custom html content', 'bingo-core');


            //block ads
            $template['desc']['ad_title'] = esc_html__('input your ad title', 'bingo-core');
            $template['desc']['ad_url'] = esc_html__('input destination URL for your advertising', 'bingo-core');
            $template['desc']['ad_image'] = esc_html__('input the URL of your advertising image ( attachment URL). This option will override on ads scripts. Leave blank if you want to use ads scripts', 'bingo-core');
            $template['desc']['ad_script'] = esc_html__('input your ad scripts or custom HTML', 'bingo-core');

            //ajax dropdown filer
            $template['title']['ajax_dropdown'] = esc_html__('ajax dropdown filter type', 'bingo-core');
            $template['desc']['ajax_dropdown'] = esc_html__('show the ajax dropdown filter at the right of block header', 'bingo-core');
            $template['input']['ajax_dropdown'] = bingo_ruby_theme_config::ajax_filter_dropdown_select();


            //ajax dropdown filer id
            $template['title']['ajax_dropdown_id'] = esc_html__('ajax dropdown filter IDs', 'bingo-core');
            $template['desc']['ajax_dropdown_id'] = esc_html__('input IDs of filter type (category IDs, author IDs, OR tag names) you want to show, separated by comas. Leave blank if you want to show all', 'bingo-core');

            //ajax dropdown text
            $template['title']['ajax_dropdown_text'] = esc_html__('ajax dropdown filter text', 'bingo-core');
            $template['desc']['ajax_dropdown_text'] = esc_html__('input text for the first item (all) of the dropdown filter', 'bingo-core');

            //ajax pagination
            $template['title']['pagination'] = esc_html__('ajax pagination', 'bingo-core');
            $template['desc']['pagination'] = esc_html__('select pagination type for this block', 'bingo-core');
            $template['input']['pagination'] = bingo_ruby_theme_config::pagination_dropdown_select();


            //view more link
            $template['title']['viewmore'] = esc_html__('View More Button', 'bingo-core');
            $template['desc']['viewmore'] = esc_html__('enable or disable view more button with link for this block', 'bingo-core');

            $template['title']['viewmore_link'] = esc_html__('View more link', 'bingo-core');
            $template['desc']['viewmore_link'] = esc_html__('input the URL of view more button', 'bingo-core');

            $template['title']['viewmore_text'] = esc_html__('view More Text', 'bingo-core');
            $template['desc']['viewmore_text'] = esc_html__('input the text of view more button', 'bingo-core');

            //grid style
            $template['title']['grid_style'] = esc_html__('Grid Style', 'bingo-core');
            $template['desc']['grid_style'] = esc_html__('select grid style for this block', 'bingo-core');
            $template['input']['grid_style'] = bingo_ruby_theme_config::grid_style_dropdown_select();

            //background color
            $template['title']['background'] = esc_html__('Background Color', 'bingo-core');
            $template['desc']['background'] = esc_html__('select background color (hex color) for this block for example: #282828', 'bingo-core');

            //background color
            $template['title']['margin_bottom'] = esc_html__('Margin Bottom', 'bingo-core');
            $template['desc']['margin_bottom'] = esc_html__('select margin bottom for this block.', 'bingo-core');

            //header color
            $template['title']['header_color'] = esc_html__('Header Color', 'bingo-core');
            $template['desc']['header_color'] = esc_html__('select text color (hex color) for header this block for example: #ffffff', 'bingo-core');

            //background header
            $template['title']['header_background'] = esc_html__('Header Background Color', 'bingo-core');
            $template['desc']['header_background'] = esc_html__('select header background color (hex color) for this block for example: #4387d2', 'bingo-core');

            //unload
            $template['unload'] = esc_html__('The changes you made will be lost if you navigate away from this page.', 'bingo-core');
			$template['confirm_section_delete'] = esc_html__( 'Are you sure to delete this section?', 'bingo-core' );
			$template['confirm_block_delete']   = esc_html__( 'Are you sure to delete this block?', 'bingo-core' );

			// sidebar
			$str = '';
			$str .= '<div class="ruby-template-field-sidebar-label"><label>' . esc_html__( 'Select Sidebar Options', 'bingo-core' ) . '</label>';
			$str .= '<div class="ruby-sidebar-select-wrap">';
			$str .= '<div class="ruby-sidebar-select-el">';
			$str .= '<div class="sidebar-label">' . esc_html__( 'Sidebar Name', 'bingo-core' ) . '</div>';
			$str .= '<select class ="ruby-sidebar-select">';

			// sidebar select
			$data_sidebar = $GLOBALS['wp_registered_sidebars'];

			if ( is_array( $data_sidebar ) ) {
				foreach ( $data_sidebar as $sidebar ) {
					if ( ! empty( $sidebar['id'] ) && ! empty( $sidebar['name'] ) ) {
						switch ( $sidebar['id'] ) {
							case 'bingo_ruby_single_post_section' :
                            case 'bingo_ruby_sidebar_footer_fullwidth' :
							case 'bingo_ruby_sidebar_footer_1' :
							case 'bingo_ruby_sidebar_footer_2' :
							case 'bingo_ruby_sidebar_footer_3':
								break;
							default:
								$str .= '<option value="' . esc_attr( $sidebar['id'] ) . '">' . ucwords( $sidebar['name'] ) . '</option>';
								break;
						}
					}
				};
			}
			$str .= '</select>';
			$str .= '</div>';
			$str .= '<div class="ruby-sidebar-select-el">';
			$str .= '<div class="sidebar-label">' . esc_html__( 'Sidebar Position', 'bingo-core' ) . '</div>';
			$str .= '<select class="ruby-sidebar-position">';
			$str .= '<option selected value ="right">' . esc_html__( 'Right', 'bingo-core' ) . '</option>';
			$str .= '<option  value ="left">' . esc_html__( 'Left', 'bingo-core' ) . '</option>';
			$str .= '</select>';
			$str .= '</div>';

			$str .= '<div class="ruby-sidebar-select-el">';
			$str .= '<div class="sidebar-label">' . esc_html__( 'Sidebar Sticky', 'bingo-core' ) . '</div>';
			$str .= '<select class="ruby-sidebar-sticky">';
			$str .= '<option selected value ="default">' . esc_html__( 'Default From Theme Options', 'bingo-core' ) . '</option>';
			$str .= '<option  value ="stick">' . esc_html__( 'Stick', 'bingo-core' ) . '</option>';
			$str .= '<option value ="none">' . esc_html__( 'None', 'bingo-core' ) . '</option>';
			$str .= '</select>';
			$str .= '</div>';

			$str .= '</div></div>';
			$template['input']['sidebar'] = $str;

			// full width section
			$str = '';
			$str .= '<div class="ruby-section fullwidth-section">';
			$str .= '<div class="ruby-section-bar">';
			$str .= '<i class="ruby-section-move">#</i>';
			$str .= '<div class="ruby-section-label"></div>';
			$str .= '<div class="ruby-section-toolbox">';
			$str .= '<a class="ruby-section-open-option" href="#">+</a>';
			$str .= '<a class="ruby-section-delete" href="#">x</a>';
			$str .= '</div>';
			$str .= '</div>';
			$str .= '<div class="ruby-block-wrap clearfix">';
			$str .= '<div class="section-menu-wrap">';
			$str .= '<div class="ruby-toolbox"><a href="#" class="add-block-select">' . esc_html__( 'Add Block', 'bingo-core' ) . '</a>';
			$str .= '<div class="block-select-wrap"></div>';
			$str .= '</div>';
			$str .= '</div>';
			$str .= '<div class="ruby-block fullwidth-block">';
			$str .= '<input type="hidden" class="ruby-section-order" name="bingo_ruby_section_order[]">';
			$str .= '<input type="hidden" class="ruby-section-type">';
			$str .= '<div class="ruby-section-empty">' . esc_html__( 'Click on " <strong>BLOCK</strong> " images to add a new block.', 'bingo-core' ) . '</div>';
			$str .= '<div class="ruby-section-loading">' . esc_html__( 'Loading ...', 'bingo-core' ) . '</div>';
			$str .= '</div>';
			$str .= '</div>';
			$str .= '</div>';
			$template['section_full_width'] = $str;

			// has sidebar section
			$str = '';
			$str .= '<div class="ruby-section has-sidebar-section">';
			$str .= '<div class="ruby-section-bar">';
			$str .= '<i class="ruby-section-move">#</i>';
			$str .= '<div class="ruby-section-label"></div>';
			$str .= '<div class="ruby-section-toolbox">';
			$str .= '<a class="ruby-section-open-option" href="#">+</a>';
			$str .= '<a class="ruby-section-delete" href="#">x</a>';
			$str .= '</div>';
			$str .= '</div>';
			$str .= '<div class="ruby-block-wrap clearfix">';
			$str .= '<div class="section-menu-wrap">';
			$str .= '<div class="ruby-section-sidebar">';
			$str .= '</div>';
			$str .= '<div class="ruby-toolbox"><a href="#" class="add-block-select">' . esc_html__( 'Add Block', 'bingo-core' ) . '</a>';
			$str .= '<div class="block-select-wrap"></div>';
			$str .= '</div>';
			$str .= '</div>';
			$str .= '<div class="ruby-block content-block">';
			$str .= '<input type="hidden" class="ruby-section-order" name="bingo_ruby_section_order[]">';
			$str .= '<input type="hidden" class="ruby-section-type">';
			$str .= '<div class="ruby-section-empty">' . html_entity_decode( esc_html__( 'Click on " <strong>BLOCK</strong> " images to add a new block.', 'bingo-core' ) ) . '</div>';
			$str .= '<div class="ruby-section-loading">' . esc_html__( 'Loading ...', 'bingo-core' ) . '</div>';
			$str .= '</div>';

			$str .= '</div>';
			$str .= '</div>';

			$template['section_has_sidebar'] = $str;

			return $template;
		}
	}
}

/** js templates */
if ( ! function_exists( 'bingo_composer_js_templates' ) ) {
	function bingo_composer_js_templates() {
		global $pagenow;
		if ( ( 'post.php' == $pagenow || 'post-new.php' == $pagenow ) && get_current_screen()->post_type == 'page' ) :
			if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'elementor' ) {
				return;
			} ?>
			<script type="text/html" id="tmpl-bingo-composer-switch-btn">
				<div class="bingo-composer-switch-mode">
					<a id="bingo_switch_mode" title="switch to Ruby Composer" class="ruby-composer-switch-btn" href="#"><i class="dashicons dashicons-migrate"></i>
						<?php esc_html_e( 'Ruby Composer', 'bingo-core' ); ?>
					</a>
				</div>
			</script>
			<script type="text/html" id="tmpl-bingo-composer-panel">
				<?php echo ruby_composer_panel_template(); ?>
			</script>
			<script type="text/html" id="tmpl-rbc-js-loaded">
				<input type="hidden" class="rbc-field" name="rbc_js_loaded" value="1">
			</script>
		<?php
		endif;
	}
}

/** panel template */
if ( ! function_exists( 'ruby_composer_panel_template' ) ) {
	function ruby_composer_panel_template() {

		$str = '';
		$str .= '<div id="bingo_composer_editor" class="ruby-composer-editor ruby-composer-gutenberg is-hidden">';
		$str .= '<div class="ruby-composer-title"><h3>' . esc_html__( 'Ruby Composer', 'bingo-core' ) . '</h3></div>';
		$str .= '<div class="ruby-composer-loading"></div>';
		$str .= '<div class="ruby-toolbox"><a href="#" id="page_composer_section_select" class="add-section-select">' . esc_html__( 'select your section', 'bingo-core' ) . '</a>';
		$str .= '<div id="bingo_section_select" class="section-select-wrap"></div>';
		$str .= '</div>';
		$str .= '<div class="ruby-sections-wrap">';
		$str .= '<div class="ruby-section-empty">' . esc_html__( 'Click on "SECTION" images to create a new section.', 'bingo-core' ) . '</div>';
		$str .= '</div>';
		$str .= '</div>';

		return $str;
	}
}


/** setup sections */
if ( ! function_exists( 'bingo_composer_sections' ) ) {
	function bingo_composer_sections() {

		$sections = array(
			'section_full_width'  => array(
				'title' => esc_html__( 'Full Width Section', 'bingo-core' ),
				'img'   => BINGO_RUBY_PLUGIN_URL . '/composer/assets/section-full-width.png',
				'decs'  => esc_html__( 'Display content without sidebar', 'bingo-core' ),
			),
			'section_has_sidebar' => array(
				'title' => esc_html__( 'Has Sidebar Section', 'bingo-core' ),
				'img'   => BINGO_RUBY_PLUGIN_URL . '/composer/assets/section-has-sidebar.png',
				'decs'  => esc_html__( 'Display content width sidebar', 'bingo-core' ),
			),

		);
		return $sections;
	}
}


/**
 * @return string
 * select category
 */
if ( ! function_exists( 'bingo_category_dropdown_select' ) ) {
	function bingo_category_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        $ruby_categories = get_categories( array(
            'hide_empty' => 0,
        ) );

        $ruby_category_array_walker = new bingo_ruby_category_array_walker;
        $ruby_category_array_walker->walk( $ruby_categories, 4 );
        $ruby_categories_buffer = $ruby_category_array_walker->cat_array;

        //render
        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="0" selected="selected">' . esc_html__( '-- All categories --', 'bingo-core' ) . '</option>';
        foreach ( $ruby_categories_buffer as $ruby_category_name => $category_id ) {
            $str .= '<option value="' . esc_attr( $category_id ) . '">';
            $str .= esc_html( $ruby_category_name );
            $str .= '</option>';
        }

        $str .= '</select><!-- category select-->';

        return $str;
	}
}

if ( ! function_exists( 'bingo_categories_dropdown_select' ) ) {
	function bingo_categories_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        if ( ! is_admin() ) {
            return false;
        }

        $ruby_categories = get_categories( array(
            'hide_empty' => 0,
        ) );

        $ruby_category_array_walker = new bingo_ruby_category_array_walker;
        $ruby_category_array_walker->walk( $ruby_categories, 4 );
        $ruby_categories_buffer = $ruby_category_array_walker->cat_array;

        //render
        $str = '';
        $str .= '<select class="ruby-field ruby-field-select" multiple="multiple">';
        $str .= '<option value="0" selected="selected">' . esc_html__( '-- Disable --', 'bingo-core' ) . '</option>';
        foreach ( $ruby_categories_buffer as $ruby_category_name => $category_id ) {
            $str .= '<option value="' . esc_attr( $category_id ) . '">';
            $str .= esc_html( $ruby_category_name );
            $str .= '</option>';
        }

        $str .= '</select>';

        return $str;
	}
}

/**
 * @return string
 * format dropdown select
 */
if ( ! function_exists( 'bingo_post_format_dropdown_select' ) ) {
	function bingo_post_format_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        //render
        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="0" selected="selected">' . esc_html__( '-- All --', 'bingo-core' ) . '</option>';
        $str .= '<option value="default">' . esc_html__( 'Default', 'bingo-core' ) . '</option>';
        $str .= '<option value="gallery">' . esc_html__( 'Gallery', 'bingo-core' ) . '</option>';
        $str .= '<option value="video">' . esc_html__( 'Video', 'bingo-core' ) . '</option>';
        $str .= '<option value="audio">' . esc_html__( 'Audio', 'bingo-core' ) . '</option>';
        $str .= '</select>';

        return $str;
	}

}


/**
 * @param bool $enable
 *
 * @return string
 * enable or disable dropdown select
 */
if ( ! function_exists( 'bingo_enable_dropdown_select' ) ) {
	function bingo_enable_dropdown_select( $disable = false ) {

		if ( ! is_admin() ) {
			return false;
		}

		// render
		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		if ( true == $disable ) {
			$str .= '<option value="0">' . esc_html__( '-- Disable --', 'bingo-core' ) . '</option>';
			$str .= '<option value="1"  selected="selected">' . esc_html__( 'Enable', 'bingo-core' ) . '</option>';
		} else {
			$str .= '<option value="0" selected="selected">' . esc_html__( '-- Disable --', 'bingo-core' ) . '</option>';
			$str .= '<option value="1">' . esc_html__( 'Enable', 'bingo-core' ) . '</option>';
		}

		$str .= '</select>';

		return $str;
	}
}


/**
 * @return string
 * select author
 */
if ( ! function_exists( 'bingo_author_dropdown_select' ) ) {
	function bingo_author_dropdown_select() {

		if ( ! is_admin() ) {
			return false;
		}

		return wp_dropdown_users(
			array(
				'show_option_all' => esc_html__( 'All Authors', 'bingo-core' ),
				'orderby'         => 'ID',
				'class'           => 'ruby-field',
				'echo'            => 0,
				'multi'           => true,
				'hierarchical'    => true
			)
		);
	}
}


/**
 * @return string
 * Order config
 */
if ( ! function_exists( 'bingo_orderby_dropdown_select' ) ) {
	function bingo_orderby_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        $orderby_data = array(
            'date_post'               => esc_html__( 'Latest Post', 'bingo-core' ),
            'comment_count'           => esc_html__( 'Popular Comment', 'bingo-core' ),
            'popular'                 => esc_html__( 'Popular View', 'bingo-core' ),
            'top_review'              => esc_html__( 'Popular Review', 'bingo-core' ),
            'post_type'               => esc_html__( 'Post Type', 'bingo-core' ),
            'rand'                    => esc_html__( 'Random', 'bingo-core' ),
            'modified'                => esc_html__( 'Last Modified Date', 'bingo-core' ),
            'author'                  => esc_html__( 'Author', 'bingo-core' ),
            'alphabetical_order_decs' => esc_html__( 'Title DECS', 'bingo-core' ),
            'alphabetical_order_asc'  => esc_html__( 'Title ACS', 'bingo-core' )
        );

        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        foreach ( $orderby_data as $val => $title ) {
            $str .= '<option value="' . esc_attr( $val ) . '">' . esc_html( $title ) . '</option>';
        }
        $str .= '</select>';

        return $str;
	}
}


/**
 * @return string
 * viewmore dropdown select
 */
if ( ! function_exists( 'bingo_viewmore_dropdown_select' ) ) {
	function bingo_viewmore_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        //render
        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="0"  selected="selected">' . esc_html__( '-- Disable --', 'bingo-core' ) . '</option>';
        $str .= '<option value="1">' . esc_html__( 'Enable', 'bingo-core' ) . '</option>';
        $str .= '</select>';

        return $str;
	}
}

/**
 * @return string
 * summary select config
 */
if ( ! function_exists( 'bingo_summary_dropdown_select' ) ) {
	function bingo_summary_dropdown_select() {

        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="excerpt">' . esc_html__( 'Use Post Excerpt', 'bingo-core' ) . '</option>';
        $str .= '<option value="moretag">' . esc_html__( 'Use More Tag', 'bingo-core' ) . '</option>';
        $str .= '</select>';

        return $str;
	}
}


/**
 * @return string
 * position dropdown select
 */
if ( ! function_exists( 'bingo_position_dropdown_select' ) ) {
	function bingo_position_dropdown_select() {
        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="0">' . esc_html__( 'Float Left', 'bingo-core' ) . '</option>';
        $str .= '<option value="1">' . esc_html__( 'Float Right', 'bingo-core' ) . '</option>';
        $str .= '</select>';

        return $str;
	}
}


/**
 * @return string
 * wrapper mode config
 */
if ( ! function_exists( 'bingo_wrapmode_dropdown_select' ) ) {
	function bingo_wrapmode_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        //render
        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="0">' . esc_html__( 'Full Width', 'bingo-core' ) . '</option>';
        $str .= '<option value="1" selected="selected">' . esc_html__( 'Has Wrapper', 'bingo-core' ) . '</option>';
        $str .= '</select>';

        return $str;
	}
}


/**
 * @return string
 * text style select
 */
if ( ! function_exists( 'bingo_text_style_dropdown_select' ) ) {
	function bingo_text_style_dropdown_select() {

        if ( ! is_admin() ) {
            return false;
        }

        $str = '';
        $str .= '<select class="ruby-field ruby-field-select">';
        $str .= '<option value="light" selected="selected">' . esc_html__( 'Light ', 'bingo-core' ) . '</option>';
        $str .= '<option value="dark">' . esc_html__( 'Dark', 'bingo-core' ) . '</option>';
        $str .= '</select>';

        return $str;
	}
}


/**
 * @return string
 * number of columns
 */
if ( ! function_exists( 'bingo_number_of_columns_select' ) ) {
	function bingo_number_of_columns_select() {

		if ( ! is_admin() ) {
			return false;
		}

		// render
		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		$str .= '<option value="1">' . esc_html__( '1 column', 'bingo-core' ) . '</option>';
		$str .= '<option value="2">' . esc_html__( '2 columns', 'bingo-core' ) . '</option>';
		$str .= '<option value="3" selected="selected">' . esc_html__( ' -- 3 columns -- ', 'bingo-core' ) . '</option>';
		$str .= '<option value="4">' . esc_html__( '4 columns', 'bingo-core' ) . '</option>';
		$str .= '</select>';

		return $str;
	}
}


/**
 * @return string
 * number of columns
 */
if ( ! function_exists( 'bingo_col_img_style_select' ) ) {
	function bingo_col_img_style_select() {

		if ( ! is_admin() ) {
			return false;
		}

		// render
		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		$str .= '<option value="1" selected="selected">' . esc_html__( '-- Style 1 ---', 'bingo-core' ) . '</option>';
		$str .= '<option value="2">' . esc_html__( 'Style 2 (Overlay)', 'bingo-core' ) . '</option>';
		$str .= '<option value="3">' . esc_html__( 'Style 3 (Overlay)', 'bingo-core' ) . '</option>';
		$str .= '</select>';

		return $str;
	}
}


/**
 * block style select
 */
if ( ! function_exists( 'bingo_block_style_dropdown_select' ) ) {
	function bingo_block_style_dropdown_select() {
		if ( ! is_admin() ) {
			return false;
		}

		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		$str .= '<option value="light" selected="selected">' . esc_html__( '-- Light --', 'bingo-core' ) . '</option>';
		$str .= '<option value="dark">' . esc_html__( 'Dark', 'bingo-core' ) . '</option>';
		$str .= '</select>';

		return $str;
	}
}


/**
 * @return string
 * ajax filter type
 */
if ( ! function_exists( 'bingo_ajax_filter_dropdown_select' ) ) {
	function bingo_ajax_filter_dropdown_select() {

		if ( ! is_admin() ) {
			return false;
		}

		$ajax_filter_dropdown_select_data = array(
			'0'        => esc_html__( '-- Disable --', 'bingo-core' ),
			'category' => esc_html__( 'by Categories', 'bingo-core' ),
			'tag'      => esc_html__( 'by Tags Names', 'bingo-core' ),
			'author'   => esc_html__( 'by Authors', 'bingo-core' ),
			'popular'  => esc_html__( 'by Popular', 'bingo-core' ),

		);

		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		foreach ( $ajax_filter_dropdown_select_data as $val => $title ) {
			$str .= '<option value="' . esc_attr( $val ) . '">' . esc_html( $title ) . '</option>';
		}
		$str .= '</select>';

		return $str;
	}
}


/**
 * @return string
 * pagination select config
 */
if ( ! function_exists( 'bingo_pagination_dropdown_select' ) ) {
	function bingo_pagination_dropdown_select() {

		if ( ! is_admin() ) {
			return false;
		}

		// render
		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		$str .= '<option value="0" selected="selected">' . esc_html__( ' -- Disable -- ', 'bingo-core' ) . '</option>';
		$str .= '<option value="next_prev">' . esc_html__( 'Next Prev', 'bingo-core' ) . '</option>';
		$str .= '<option value="loadmore">' . esc_html__( 'Load More', 'bingo-core' ) . '</option>';
		$str .= '<option value="infinite_scroll">' . esc_html__( 'infinite Scroll', 'bingo-core' ) . '</option>';
		$str .= '</select>';

		return $str;
	}
}


/**
 * @return string
 * grid style select
 */
if ( ! function_exists( 'bingo_grid_style_dropdown_select' ) ) {
	function bingo_grid_style_dropdown_select() {

		if ( ! is_admin() ) {
			return false;
		}

		// render
		$str = '';
		$str .= '<select class="ruby-field ruby-field-select">';
		$str .= '<option value="1" selected="selected">' . esc_html__( ' -- Style 1 -- ', 'bingo-core' ) . '</option>';
		$str .= '<option value="2">' . esc_html__( 'Style 2 (Top Title)', 'bingo-core' ) . '</option>';
		$str .= '<option value="3">' . esc_html__( 'Style 3 (Middle Title)', 'bingo-core' ) . '</option>';
		$str .= '<option value="4">' . esc_html__( 'Style 4 (Rainbow)', 'bingo-core' ) . '</option>';
		$str .= '<option value="5">' . esc_html__( 'Style 5 (Rainbow + Middle Title)', 'bingo-core' ) . '</option>';
		$str .= '</select>';

		return $str;
	}
}


if ( ! class_exists( 'bingo_category_array_walker' ) ) {
	class bingo_category_array_walker extends Walker {

		var $tree_type = 'category';
		var $cat_array = array();
		var $db_fields = array(
			'id'     => 'term_id',
			'parent' => 'parent'
		);

		public function start_lvl( &$output, $depth = 0, $args = array() ) {
		}

		public function end_lvl( &$output, $depth = 0, $args = array() ) {
		}

		public function start_el( &$output, $object, $depth = 0, $args = array(), $current_object_id = 0 ) {
			$this->cat_array[ str_repeat( ' - ', $depth ) . $object->name . ' - [ ID: ' . $object->term_id . ' / Posts: ' . $object->category_count . ' ]' ] = $object->term_id;
		}

		public function end_el( &$output, $object, $depth = 0, $args = array() ) {
		}

	}
}
