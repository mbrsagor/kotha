<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'display_post_states', 'bingo_show_composer_state' );
add_action( 'add_meta_boxes', 'bingo_register_composer_meta', 0 );
add_action( 'admin_enqueue_scripts', 'bingo_composer_scripts' );
add_action( 'admin_footer', 'bingo_composer_js_templates' );
add_action( 'save_post', 'bingo_save_composer_data', 10 );

/** register metabox */
if ( ! function_exists( 'bingo_register_composer_meta' ) ) {
	function bingo_register_composer_meta() {
		if ( ! is_admin() ) {
			return false;
		}

		$section = array(
			'title'      => esc_html__( 'RUBY COMPOSER', 'rbc' ),
			'context'    => 'normal',
			'post_types' => array( 'page' ),
			'priority'   => 'high',
		);

		add_meta_box( 'rbc-global-meta', $section['title'], 'bingo_composer_global_panel', $section['post_types'], $section['context'], $section['priority'], $section );

		return false;
	}
}

/** rbc meta nonce */
if ( ! function_exists( 'bingo_composer_global_panel' ) ) {
	function bingo_composer_global_panel() {
		wp_nonce_field( basename( __FILE__ ), 'rbc_meta_nonce' );
	}
}


if ( ! function_exists( 'bingo_composer_scripts' ) ) {
	function bingo_composer_scripts() {

		global $pagenow;
		if ( ( 'post.php' == $pagenow || 'post-new.php' == $pagenow ) && get_current_screen()->post_type == 'page' ) {
			if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'elementor' ) {
				return;
			}

			wp_enqueue_style( 'bingo_ruby_composer_style', BINGO_RUBY_PLUGIN_URL . '/composer/assets/composer.css', array(), BINGO_CORE_VERSION, 'all' );
			wp_register_script( 'bingo_ruby_composer_script', BINGO_RUBY_PLUGIN_URL . '/composer/assets/composer.js', array(
				'jquery',
				'wp-util'
			), BINGO_CORE_VERSION, true );

			$blocks        = '';
			$templates     = bingo_composer_templates();
			$sections      = bingo_composer_sections();
			$composer_data = bingo_composer_get_data();
			if ( function_exists( 'bingo_composer_blocks' ) ) {
				$blocks = bingo_composer_blocks();
			}

			wp_localize_script( 'bingo_ruby_composer_script', 'bingo_setup_sections', $sections );
			wp_localize_script( 'bingo_ruby_composer_script', 'bingo_composer_template', $templates );
			wp_localize_script( 'bingo_ruby_composer_script', 'bingo_setup_blocks', $blocks );
			wp_localize_script( 'bingo_ruby_composer_script', 'bingo_page_composer_data', $composer_data );
			wp_enqueue_script( 'bingo_ruby_composer_script' );
		}
	}
}

/** show composer stage */
if ( ! function_exists( 'bingo_show_composer_state' ) ) {
	function bingo_show_composer_state( $states ) {
		global $post;
		global $pagenow;
		if ( 'edit.php' == $pagenow && get_current_screen()->post_type == 'page' ) {
			if ( 'page' == get_post_type( $post->ID ) && 'page-composer.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
				$states[] = esc_html__( 'Ruby Composer', 'rbc' );
			}
		}

		return $states;
	}
}

/** get composer data */
if ( ! function_exists( 'bingo_composer_get_data' ) ) {
	function bingo_composer_get_data() {

		global $post;
		$data = array();
		if ( isset( $post->ID ) && 'page-composer.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
			$data = get_post_meta( $post->ID, 'bingo_ruby_page_composer_data', true );
			$data = stripslashes_deep( $data );
		}

		return $data;
	}
}


// init composer data
if ( ! function_exists( 'bingo_save_composer_data' ) ) {
	function bingo_save_composer_data() {

		if ( empty( $_POST['post_ID'] ) ) {
			return false;
		}

		$page_id     = esc_attr( $_POST['post_ID'] );
		$is_autosave = wp_is_post_autosave( $page_id );
		$is_revision = wp_is_post_revision( $page_id );

		$is_valid_nonce = ( isset( $_POST['rbc_meta_nonce'] ) && wp_verify_nonce( $_POST['rbc_meta_nonce'], basename( __FILE__ ) ) ) ? true : false;

		if ( $is_autosave || $is_revision || ! $is_valid_nonce ) {
			return false;
		}

		if ( empty( $_POST['post_type'] ) || 'page' != $_POST['post_type'] || ( ! empty( $_POST['action'] ) && 'inline-save' == $_POST['action'] ) ) {
			return false;
		}

		if ( empty( $_POST['rbc_js_loaded'] ) ) {
			return false;
		}

		$data = array();
		if ( ! isset( $_POST['bingo_ruby_section_order'] ) ) {
			if ( 'page-composer.php' == get_post_meta( $page_id, '_wp_page_template', true ) ) {
				delete_post_meta( $page_id, 'bingo_ruby_page_composer_data' );
			}

			return false;
		};

		if ( ! is_array( $_POST['bingo_ruby_section_order'] ) ) {
			return false;
		}

		foreach ( $_POST['bingo_ruby_section_order'] as $section_id ) {

			$section_id = sanitize_text_field( $section_id );

			if ( ! isset( $_POST[ 'bingo_ruby_section_' . $section_id ] ) ) {
				return false;
			}

			$section_type = sanitize_text_field( $_POST[ 'bingo_ruby_section_' . $section_id ] );

			if ( $section_type == 'section_has_sidebar' ) {

				$section_sidebar          = '';
				$section_sidebar_position = '';
				$section_sidebar_sticky   = '';

				if ( ! empty ( $_POST[ 'bingo_ruby_sidebar_' . $section_id ] ) ) {
					$section_sidebar = sanitize_text_field( $_POST[ 'bingo_ruby_sidebar_' . $section_id ] );
				}
				if ( ! empty( $_POST[ 'bingo_ruby_meta_sidebar_position_' . $section_id ] ) ) {
					$section_sidebar_position = sanitize_text_field( $_POST[ 'bingo_ruby_meta_sidebar_position_' . $section_id ] );
				}

				if ( ! empty( $_POST[ 'bingo_ruby_meta_sidebar_sticky_' . $section_id ] ) ) {
					$section_sidebar_sticky = sanitize_text_field( $_POST[ 'bingo_ruby_meta_sidebar_sticky_' . $section_id ] );
				}

				$data[ $section_id ]['section_sidebar']          = $section_sidebar;
				$data[ $section_id ]['section_sidebar_position'] = $section_sidebar_position;
				$data[ $section_id ]['section_sidebar_sticky']   = $section_sidebar_sticky;
			}

			$data[ $section_id ]['section_type'] = $section_type;
			$data[ $section_id ]['section_id']   = $section_id;

			if ( ! isset( $_POST['bingo_ruby_block_order'][ $section_id ] ) ) {
				continue;
			}

			$blocks_of_section = array_map( 'sanitize_text_field', $_POST['bingo_ruby_block_order'][ $section_id ] );
			$blocks            = array();
			if ( is_array( $blocks_of_section ) ) {
				foreach ( $blocks_of_section as $block ) {
					$block_name                     = 'bingo_ruby_block_' . $block;
					$name                           = sanitize_text_field( $_POST[ $block_name ] );
					$blocks[ $block ]['block_name'] = $name;
					$blocks[ $block ]['block_id']   = $block;

					if ( isset( $_POST['bingo_ruby_block_option'][ $block_name ] ) ) {
						$block_options = $_POST['bingo_ruby_block_option'][ $block_name ];
						foreach ( $block_options as $option_name => $option ) {
							$option_name                                       = sanitize_text_field( $option_name );
							$option                                            = bingo_sanitize_input( $option_name, $option );
							$blocks[ $block ]['block_options'][ $option_name ] = $option;
						}
					}
				}
			}
			$data[ $section_id ]['blocks'] = $blocks;
		}

		// save composer data
		delete_post_meta( $page_id, 'bingo_ruby_composer_dynamic_style_cache' );
		update_post_meta( $page_id, 'bingo_ruby_page_composer_data', $data );

		return false;
	}
}

/** bingo_sanitize_input */
if ( ! function_exists( 'bingo_sanitize_input' ) ) {
	function bingo_sanitize_input( $option_name = '', $option = '' ) {
		switch ( $option_name ) {
			case 'custom_html' :
			case 'raw_html_1' :
			case 'raw_html_2' :
			case 'raw_html_3' :
			case 'raw_html_4' :
			case 'shortcode' :
			case 'ad_script' :
				return addslashes( $option );
			case 'title_url'  :
			case 'image_url'  :
			case 'destination_1':
			case 'destination_2':
			case 'destination_3':
			case 'destination_4':
				return esc_url( $option );
			case 'category_ids' : {
				$options = array();
				if ( is_array( $option ) ) {
					foreach ( $option as $option_el ) {
						$options[] = esc_attr( $option_el );
					}
				}

				return $options;
			}
			default :
				return sanitize_text_field( $option );
		}
	}
}





